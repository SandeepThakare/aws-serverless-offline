(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

	var _TacoGallery = __webpack_require__(1);

	var _TacoGallery2 = _interopRequireDefault(_TacoGallery);

	var _lib = __webpack_require__(6);

	var _lib2 = _interopRequireDefault(_lib);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	var isString = function isString(obj) {
		return typeof obj === 'string' || obj instanceof String;
	};

	module.exports.hello = function (event, context, callback) {
		var tacoGallery = new _TacoGallery2.default();

		var response = {
			statusCode: 200,
			headers: {
				'Access-Control-Allow-Origin': '*', // Required for CORS support to work
				'Access-Control-Allow-Credentials': true // Required for cookies, authorization headers with HTTPS
			},
			body: JSON.stringify(tacoGallery.hello(event))
		};

		callback(null, response);
	};

	module.exports.saveTaco = function (event, context, callback) {
		var tacoGallery = new _TacoGallery2.default();
		console.log(_typeof(event.body));
		var params = isString(event.body) ? JSON.parse(event.body) : event.body;

		tacoGallery.saveTaco(params).then(function (data) {
			var response = {
				statusCode: 200,
				body: JSON.stringify(data)
			};

			callback(null, response);
		}).catch(function (err) {
			var response = {
				statusCode: 409,
				body: {
					message: 'Could not save the taco',
					stack: err
				}
			};

			callback(null, response);
		});
	};

	module.exports.getTaco = function (event, context, callback) {
		var tacoGallery = new _TacoGallery2.default();
		var id = event.pathParameters.id;

		tacoGallery.getTaco(id).then(function (data) {
			var response = {
				statusCode: 200,
				body: JSON.stringify(data)
			};

			callback(null, response);
		}).catch(function (err) {
			var response = {
				statusCode: 409,
				body: {
					message: 'Could not save the taco',
					stack: err
				}
			};

			callback(null, response);
		});
	};

	// Lambda function index.handler - thin wrapper around lib.authenticate
	module.exports.auth = function (event, context) {
		try {
			_lib2.default.authenticate(event).then(context.succeed).catch(function (err) {
				if (!err) context.fail('Unhandled error case');
				//      if ( err.message ) context.fail( err.message );
				console.log(err);
				context.fail(err);
			});
		} catch (err) {
			console.log(err);
			context.fail(err);
		}
	};

/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	var _uuid = __webpack_require__(2);

	var _uuid2 = _interopRequireDefault(_uuid);

	var _serverlessDynamodbClient = __webpack_require__(3);

	var _serverlessDynamodbClient2 = _interopRequireDefault(_serverlessDynamodbClient);

	var _Utils = __webpack_require__(4);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	var TacoGallery = function () {
		function TacoGallery() {
			_classCallCheck(this, TacoGallery);

			this.db = _serverlessDynamodbClient2.default.doc;
			this.v = new _Utils.ValidationUtils();
		}

		_createClass(TacoGallery, [{
			key: 'hello',
			value: function hello(event) {
				return {
					message: 'Go Serverless v1.0! Your function executed successfully!',
					input: event
				};
			}
		}, {
			key: 'saveTaco',
			value: function saveTaco(taco) {
				var _this = this;

				var id = _uuid2.default.v4();
				var params = {
					TableName: 'TacoGallery',
					Item: Object.assign({
						'id': id
					}, taco)
				};

				return this.v.validate(taco, '/Taco').then(function (data) {
					return _this.db.put(params).promise().then(function (data) {
						data = Object.assign({ id: id }, data);
						return data;
					});
				});
			}
		}, {
			key: 'getTaco',
			value: function getTaco(id) {
				var params = {
					TableName: 'TacoGallery',
					KeyConditionExpression: '#id = :idValue',
					ExpressionAttributeNames: {
						'#id': 'id'
					},
					ExpressionAttributeValues: {
						':idValue': id
					}
				};

				return this.db.query(params).promise();
			}
		}]);

		return TacoGallery;
	}();

	module.exports = TacoGallery;

/***/ }),
/* 2 */
/***/ (function(module, exports) {

	module.exports = require("uuid");

/***/ }),
/* 3 */
/***/ (function(module, exports) {

	module.exports = require("serverless-dynamodb-client");

/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	exports.ValidationUtils = undefined;

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }(); /**
	                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      * Created by pedro on 3/5/17.
	                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      */


	var _jsonschema = __webpack_require__(5);

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	var ValidationUtils = function () {
		function ValidationUtils() {
			_classCallCheck(this, ValidationUtils);

			this.v = new _jsonschema.Validator();

			var schema = {
				'id': '/Taco',
				'type': 'object',
				'properties': {
					'name': { 'type': 'string' },
					'description': { 'type': 'string' }
				},
				'required': ['name'],
				'additionalProperties': false
			};

			this.v.addSchema(schema, '/Taco');
		}

		_createClass(ValidationUtils, [{
			key: 'validate',
			value: function validate(object, type) {
				var _this = this;

				var schema = this.v.schemas[type];

				return new Promise(function (resolve, reject) {
					var validation = _this.v.validate(object, schema);
					if (validation.errors.length > 0) {
						console.log(validation);
						reject(validation.errors);
					} else {
						resolve();
					}
				});
			}
		}]);

		return ValidationUtils;
	}();

	exports.ValidationUtils = ValidationUtils;

/***/ }),
/* 5 */
/***/ (function(module, exports) {

	module.exports = require("jsonschema");

/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	var policyDocument = __webpack_require__(7);
	var ACCESS_TOKEN_LENGTH = 16; // (apparent) length of an Autho0 access_token

	var AWS = __webpack_require__(8);
	if (process.env.AWS_REGION) {
		AWS.config.update({ region: process.env.AWS_REGION });
	}

	var AuthenticationClient = __webpack_require__(9).AuthenticationClient;

	if (typeof process.env.AUTH0_DOMAIN === "undefined" || !process.env.AUTH0_DOMAIN.match(/\.auth0\.com$/)) {
		throw new Error("Expected AUTHO_DOMAIN environment variable to be set in .env file. See https://manage.auth0.com/#/applications");
	}

	if (typeof process.env.AUTH0_CLIENTID === "undefined" || process.env.AUTH0_CLIENTID.length === 0) {
		throw new Error("Expected AUTH0_CLIENTID environment variable to be set in .env file. See https://manage.auth0.com/#/applications");
	}

	var auth0 = new AuthenticationClient({
		domain: process.env.AUTH0_DOMAIN,
		clientId: process.env.AUTH0_CLIENTID
	});

	// extract and return the Bearer Token from the Lambda event parameters
	var getToken = function getToken(params) {
		var token;

		if (!params.type || params.type !== 'TOKEN') {
			throw new Error("Expected 'event.type' parameter to have value TOKEN");
		}

		var tokenString = params.authorizationToken;
		if (!tokenString) {
			throw new Error("Expected 'event.authorizationToken' parameter to be set");
		}

		var match = tokenString.match(/^Bearer (.*)$/);
		if (!match || match.length < 2) {
			throw new Error("Invalid Authorization token - '" + tokenString + "' does not match 'Bearer .*'");
		}
		return match[1];
	};

	var returnAuth0UserInfo = function returnAuth0UserInfo(auth0return) {
		if (!auth0return) throw new Error('Auth0 empty return');
		if (auth0return === 'Unauthorized') {
			throw new Error('Auth0 reports Unauthorized');
		} else if (!auth0return) {}

		return auth0return;
	};

	var saveUserInfo = function saveUserInfo(userInfo) {
		if (!userInfo) throw new Error('saveUserInfo - expected userInfo parameter');
		if (!userInfo.user_id) throw new Error('saveUserInfo - expected userInfo.user_id parameter');
		console.log(userInfo);
		//Use this space if you want to save the user
		return userInfo;
	};

	// extract user_id from the autho0 userInfo and return it for AWS principalId
	var getPrincipalId = function getPrincipalId(userInfo) {
		if (!userInfo || !userInfo.user_id) {
			throw new Error("No user_id returned from Auth0");
		}
		console.log('Auth0 authentication successful for user_id ' + userInfo.user_id);

		return userInfo.user_id;
	};

	// return the expected Custom Authorizaer JSON object
	var getAuthentication = function getAuthentication(principalId) {
		return {
			principalId: principalId,
			policyDocument: policyDocument
		};
	};

	module.exports.authenticate = function (params) {
		var token = getToken(params);

		var getTokenDataPromise;
		if (token.length === ACCESS_TOKEN_LENGTH) {
			// Auth0 v1 access_token (deprecated)
			getTokenDataPromise = auth0.users.getInfo(token);
		} else if (token.length > ACCESS_TOKEN_LENGTH) {
			// (probably) Auth0 id_token
			getTokenDataPromise = auth0.tokens.getInfo(token);
		} else {
			throw new TypeError("Bearer token too short - expected >= 16 charaters");
		}

		return getTokenDataPromise.then(returnAuth0UserInfo).then(saveUserInfo).then(getPrincipalId).then(getAuthentication);
	};

/***/ }),
/* 7 */
/***/ (function(module, exports) {

	module.exports = {"Version":"2012-10-17","region":"us-east-1","Statement":[{"Sid":"Stmt1459758003000","Effect":"Allow","Action":["execute-api:Invoke"],"Resource":["arn:aws:execute-api:*"]}]}

/***/ }),
/* 8 */
/***/ (function(module, exports) {

	module.exports = require("aws-sdk");

/***/ }),
/* 9 */
/***/ (function(module, exports) {

	module.exports = require("auth0");

/***/ })
/******/ ])));